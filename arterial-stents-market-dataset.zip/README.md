# Arterial Stents Market Dataset
This dataset is structured similarly to the Immunoglobulin Market GitHub dataset.  
It contains market overview, segmentation details, and metadata extracted from publicly available summaries.

## Files
- `market_overview.csv`
- `segmentation.csv`
- `metadata.json`
- `README.md`

## Source
https://www.nextmsc.com/report/arterial-stents-market-hc3570
